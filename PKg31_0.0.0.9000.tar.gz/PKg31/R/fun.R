#' Hello World
#'
#' `hello` says _'Hello, world!'_ in a specific languages
#'
#' @param
#'     who: specifies the name of the person to whom the “hello” message is addressed. This must be a character vector of length 1.
#' @param
#'     lang: a character vector of length 1 that specifies the user preferred language. This can be “EN” (the default value) for English, “FR” for French, “IT” for Italian, “ES” for Spanish, or “DE” for German
#' @param
#'      LangData: an optional data.frame with two columns
#'
#' @author
#'      khadija Sossey ksossey@yahoo.fr
#'
hello <- function(who, lang = "EN", LangData = language) {
  if (!exists("who", mode = "character") | length(who) > 1) stop("Please enter a valid namea; see ?hello")

  LangData <- data.frame(LangData)

  if (ncol(LangData) > 2) stop("Please enter a valid LangData; see ?hello")

  colnames(LangData) <- c("code", "hello")

  if ((mode(LangData$code) != "character") | (mode(LangData$hello) != "character")) stop("Please enter a valid LangData; see ?hello")

  llang <- tolower(lang)

  hello <- subset(LangData, LangData$code==llang)[[2]]

  cat(
    ifelse(
      length(hello) == 1,
      stringr::str_c(hello, ", ", who, "!", sep = ""),
      stringr::str_c("Sorry, ", who, ", ", "your language ", "('", lang, "') ", "is not available!", sep = "")
    )
  )
}



