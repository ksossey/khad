#' language hello.
#'
#' A dataset containing the code and hello
#' language.
#'
#' @format A data frame with 5 rows and 2 variables:
#'  @param
#'    code: language codes "fr", "it", "es", "de"
#'
#'    hello: words hello in the language corresponding to the code
#' @author
#'     sossey khadija
#'     ksossey@yahoo.fr
#'
#'
#'
#'
#'
"language"
